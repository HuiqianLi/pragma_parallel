import heapq
import math

class HuffmanNode:
    def __init__(self, char, freq):
        self.char = char    # 结点代表的字符
        self.freq = freq    # 字符出现的频率
        self.left = None
        self.right = None

    # 优先队列比较方法
    def __lt__(self, other):
        return self.freq < other.freq

class HuffmanTree:
    def __init__(self, text):
        self.root = None
        self.codes = {} # # 存储字符和对应的哈夫曼编码
        self._build_tree(text)

    def _build_tree(self, text):
        # 统计所有字符的出现次数
        freq = {}
        for char in text:
            if char not in [' ', '\n']:
                freq[char] = freq.get(char, 0) + 1

        # 将每个字符对应的HuffmanNode节点加入堆中
        # heapq.heappush ()是往堆中添加新值，此时自动建立了小根堆
        heap = []
        for char, freq in freq.items():
            heapq.heappush(heap, HuffmanNode(char, freq))

        # 构建哈夫曼树
        while len(heap) > 1:
            node1 = heapq.heappop(heap)
            node2 = heapq.heappop(heap)
            # 选取两个频率最小的节点合并为一个新节点
            merged_node = HuffmanNode(None, node1.freq + node2.freq)
            merged_node.left, merged_node.right = node1, node2
            heapq.heappush(heap, merged_node)

        self.root = heap[0]
        # 生成哈夫曼编码
        self._generate_code_table(self.root, "")

    def _generate_code_table(self, node, code):
        if node is None:
            return
        if node.char is not None:
            self.codes[node.char] = code
        # 递归遍历左右子树，生成每个字符的哈夫曼编码
        self._generate_code_table(node.left, f"{code}0")
        self._generate_code_table(node.right, f"{code}1")


def compress(input_file, output_file):
    # 读取 orignal.txt 文件
    with open(input_file, "r", encoding="utf-8") as f:
        text = f.read()

    # 构建哈夫曼树
    tree = HuffmanTree(text)

    # 使用哈夫曼编码
    huffman_binary = "".join(tree.codes[char] for char in text if char not in [' ', '\n'])

    # 计算哈夫曼编码长度
    huffman_size = len(huffman_binary)

    # 输出编码
    n = 0
    with open(output_file, "w", encoding="utf-8") as f:
        f.write("字符\t出现频率\t编码\n")
        for char, freq in sorted(tree.codes.items()):
            if char not in [' ', '\n']:
                n += 1
                f.write(f"{char}\t{text.count(char)}\t{freq}\n")
        # f.write(f"\nHuffman编码：{huffman_binary}")

    # 计算固定编码长度
    bits = math.ceil(math.log2(n))
    fixed_length_size = bits * sum(1 for char in text if char not in [' ', '\n'])
    
    # 计算压缩率
    compression_ratio = huffman_size / fixed_length_size
    print(f"Compression ratio: {compression_ratio:.4%}")

if __name__=='__main__':
    compress("orignal.txt", "table.txt")