import itertools

# 构造LCS
def get_lcs_1(s1, s2, dp):
    m, n = len(s1), len(s2)
    lcs = ''
    i, j = m, n
    while i > 0 and j > 0:
        if s1[i-1] == s2[j-1]:
            lcs = s1[i-1] + lcs
            i -= 1
            j -= 1
        elif dp[i-1][j] > dp[i][j-1]:
            i -= 1
        else:
            j -= 1
    return lcs

def lcs_length_1(s1, s2):
    m, n = len(s1), len(s2)
    # 初始化dp数组
    dp = [[0] * (n+1) for _ in range(m+1)]
    # 动态规划求解
    for i, j in itertools.product(range(1, m+1), range(1, n+1)):
        dp[i][j] = (
            dp[i - 1][j - 1] + 1
            if s1[i - 1] == s2[j - 1]
            else max(dp[i - 1][j], dp[i][j - 1])
        )
    # 返回LCS的长度以及LCS本身
    return dp[m][n], get_lcs_1(s1, s2, dp)

# 时间复杂度O(mn)，空间复杂度O(2*min(m,n))
def lcs_length_2(s1, s2):
    m, n = len(s1), len(s2)
    if m < n:
        s1, s2 = s2, s1
        m, n = n, m

    # 初始化dp数组    
    dp = [[0] * (n+1) for _ in range(2)]

    # 动态规划求解
    for i, j in itertools.product(range(1, m+1), range(1, n+1)):
        if s1[i - 1] == s2[j - 1]:
            dp[i % 2][j] = dp[(i - 1) % 2][j - 1] + 1
        elif dp[(i - 1) % 2][j] > dp[i % 2][j - 1]:
            dp[i % 2][j] = dp[(i - 1) % 2][j] 
        else:
            dp[i % 2][j] = dp[i % 2][j - 1]

    return dp[m%2][n]

# 时间复杂度O(mn)，空间复杂度O(min(m,n))
def lcs_length_3(s1, s2):
    m, n = len(s1), len(s2)
    if m < n:
        s1, s2 = s2, s1
        m, n = n, m
    # 初始化dp数组
    dp = [0] * (n+1)
    # 动态规划求解
    for i in range(m):
        dp[0] = 0
        for j in range(n):
            if s1[i] == s2[j]:
                dp[j], dp[0] = dp[0], dp[j] + 1 # 回溯时需要向左上方移动
            else:
                dp[j] = dp[0]
                dp[0] = max(dp[j+1], dp[0])
        dp[n] = dp[0]
    # 函数返回 dp[n]，即最长公共子序列的长度
    return dp[n]

if __name__=='__main__':
    # s1 = 'abcdefghigkllmnopqrssstuvwxyz'
    # s2 = 'aabcdefghigklmnopopqrsttuvwxyz'
    while True:
        s1 = input("输入text1 = ")
        s2 = input("输入text2 = ")
        print('方法一：LCS：',lcs_length_1(s1, s2)[1],'， 长度：', lcs_length_1(s1, s2)[0])
        print('方法二：', lcs_length_2(s1, s2))
        print('方法三：', lcs_length_3(s1, s2))