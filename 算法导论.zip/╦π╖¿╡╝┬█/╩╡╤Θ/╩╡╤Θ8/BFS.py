from collections import deque

# 定义颜色常量
WHITE = 0
GRAY = 1
BLACK = 2

# 使用 BFS 算法对图进行遍历
def bfs(graph, start, nodes_dict):
    n = len(graph)
    colors = [WHITE] * n  # 记录节点的颜色
    queue = deque()  # 定义队列
    queue.append(start)  # 将起始顶点加入队列中
    colors[start] = GRAY  # 将起始顶点标记为灰色

    while queue:
        node = queue.popleft()
        # print(node, end=" ")
        print(nodes_dict[node], end=" ")
        for i in range(n):
            if graph[node][i] == 1 and colors[i] == WHITE:
                queue.append(i)
                colors[i] = GRAY
        colors[node] = BLACK  # 将当前节点标记为黑色


if __name__ == '__main__':
    # 读取数据文件
    with open(".archdata.txt", "r") as f:
        lines = f.readlines()
        nodes = lines.pop(0).strip().split(",")  # 获取节点列表
        n = len(nodes)  # 节点数量
        edges = [(line.strip()[0], line.strip()[2]) for line in lines]  # 获取边列表

    # 初始化邻接矩阵，节点少边密集时使用邻接矩阵存储图
    adj_matrix = [[0] * n for _ in range(n)]

    # 填充邻接矩阵
    for edge in edges:
        i, j = nodes.index(edge[0]), nodes.index(edge[1])
        adj_matrix[i][j] = 1
        adj_matrix[j][i] = 1

    # 构建节点字母和索引的映射关系
    nodes_dict = {i: nodes[i] for i in range(n)}

    # 以 A 为起点进行 BFS 遍历
    start = nodes.index("A")
    bfs(adj_matrix, start, nodes_dict)