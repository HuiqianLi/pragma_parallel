from collections import deque
import time

class Graph:
    def __init__(self):
        self.adj_list = {}

    def add_edge(self, u, v):
        if u not in self.adj_list:
            self.adj_list[u] = {"color": "white", "neighbors": []}
        if v not in self.adj_list:
            self.adj_list[v] = {"color": "white", "neighbors": []}
        self.adj_list[u]["neighbors"].append(v)

    def bfs(self, start):
        for u in self.adj_list:
            self.adj_list[u]["color"] = "white" # 所有节点初始都设置为白色
        self.adj_list[start]["color"] = "gray" # 将起始节点标记为灰色
        queue = deque([start])
        nodes_visited = 0
        start_time = time.time()
        while queue:
            u = queue.popleft()
            nodes_visited += 1
            for v in self.adj_list[u]["neighbors"]:
                if self.adj_list[v]["color"] == "white":
                    self.adj_list[v]["color"] = "gray"
                    queue.append(v)
            self.adj_list[u]["color"] = "black"
        end_time = time.time()
        print("初始节点为{}，BFS遍历用时{:.8f}秒，访问了{}个节点。".format(start, end_time - start_time, nodes_visited))

    def bfs_all(self):
        components = 0
        for u in self.adj_list:
            if self.adj_list[u]["color"] == "white":
                self.bfs(u)
                components += 1
        print("BFS共有{}个连通部分。".format(components))


if __name__ == '__main__':
    # 读取数据文件
    with open("dataset\\twitter_small.txt", "r") as f:
        lines = f.readlines()
        edges = [(int(line.strip().split()[0]), int(line.strip().split()[1])) for line in lines]

    # 构建有向图
    graph = Graph()
    for edge in edges:
        graph.add_edge(edge[0], edge[1])

    # 进行BFS遍历
    graph.bfs_all()