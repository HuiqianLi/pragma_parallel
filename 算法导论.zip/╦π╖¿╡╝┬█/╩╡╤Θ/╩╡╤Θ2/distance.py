import time

# 计算两点间的距离
def distance(p1, p2):
    return (p1[1]-p2[1])**2 + (p1[2]-p2[2])**2
    # return math.sqrt((p1[1]-p2[1])**2 + (p1[2]-p2[2])**2)

# 暴力算法
def brute_force(points):
    n = len(points)
    if n < 2:
        return None
    elif n == 2:
        return points[0], points[1]
    else:
        min_dist = float('inf')
        closest_pair = None
        for i in range(n-1):
            for j in range(i+1, n):
                dist = distance(points[i], points[j])
                if dist < min_dist:
                    min_dist = dist
                    closest_pair = points[i], points[j]
        return closest_pair

# 分治法
def closest_pair(points):
    # 将点按横坐标排序
    points = sorted(points, key=lambda point: point[1])
    n = len(points)
    if n <= 1:
        return None
    elif n == 2:
        return points[0], points[1]
    else:
        # 将点分为两部分
        mid = n // 2
        left_half = points[:mid]
        right_half = points[mid:]

        # 递归这两部分
        left_pair = closest_pair(left_half)
        right_pair = closest_pair(right_half)

        # 在这两个部分中找到距离最短的点对，以此作为分割线，继续递归地解决子问题
        if left_pair and right_pair:
            if distance(left_pair[0], left_pair[1]) < distance(right_pair[0], right_pair[1]):
                closest = left_pair
            else:
                closest = right_pair
        elif left_pair:
            closest = left_pair
        else:
            closest = right_pair

        # 划分红色区域，上述最短点对距离为k
        y_strip = []
        for point in points:
            if abs(point[1] - points[mid][1]) < distance(closest[0], closest[1]):
                y_strip.append(point)
        # 将红色区域内的点按纵坐标从小到大排序
        y_strip = sorted(y_strip, key=lambda point: point[2])
        for i in range(len(y_strip)-1):
            # 对于区域内的每一个点，只计算它与序号在它之后的7个点之间的距离并与当前最短距离比较
            for j in range(i+1, min(i+8, len(y_strip))):
                dist = distance(y_strip[i], y_strip[j])
                if dist < distance(closest[0], closest[1]):
                    closest = y_strip[i], y_strip[j]

        return closest

# 将函数作为参数传入
def main(func, func_name):
    # 读入points
    with open('data.txt', 'r') as f:
        points = [tuple(map(float, line.strip().split())) for line in f]
    
    start_time = time.time()
    
    res = func(points)
    print(" 最近点对为 ", res)

    end_time = time.time()
    print(f' {func_name} 运行时间为 {(end_time - start_time)*1000:.2f} 毫秒')


if __name__=='__main__':
    # main(brute_force, func_name='暴力算法')     # 暴力算法：运行时间为 13551.76 毫秒
    main(closest_pair, func_name='分治法')      # 分治法