class Node:
    def __init__(self, key):
        self.key = key
        self.color = "RED"
        self.parent = None
        self.left = None
        self.right = None

class RedBlackTree:
    def __init__(self):
        self.root = None
        self.num_cases = [0] * 7

    def insert(self, key):
        node = Node(key)
        self._insert_node(node)

    def _insert_node(self, node):
        # Binary Search Tree insert
        # 使用二叉搜索树的方式将节点插入到合适的位置
        # 从根节点开始，逐层向下遍历，
        # 根据节点的大小关系选择左子树或右子树作为下一步遍历的方向，
        # 直到找到一个空节点位置，将新节点插入其中。
        parent = None
        curr = self.root
        while curr is not None:
            parent = curr
            curr = curr.left if node.key < curr.key else curr.right
        node.parent = parent
        if parent is None:
            self.root = node
        elif node.key < parent.key:
            parent.left = node
        else:
            parent.right = node

        # Red-Black Tree fixup
        self._fixup(node)

    def _fixup(self, node):
        num_cases = [0] * 7
        # 如果父节点是红色，那么需要进行修正
        while node.parent is not None and node.parent.color == "RED":
            # 父节点是祖父节点的左孩子
            if node.parent == node.parent.parent.left:
                uncle = node.parent.parent.right
                # 【情况1】叔节点是红色
                if uncle is not None and uncle.color == "RED":
                    # 父节点和叔节点涂黑，祖父节点涂红
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    node.parent.parent.color = "RED"
                    # 将祖父节点作为新的插入节点，继续进行修正
                    node = node.parent.parent
                    self.num_cases[1] += 1
                else:
                    # 【情况2】叔节点是黑色，且当前节点是右孩子
                    if node == node.parent.right:
                        # 将父节点作为新的插入节点，进行左旋
                        node = node.parent
                        self._left_rotate(node)
                        self.num_cases[2] += 1
                    # 【情况3】叔节点是黑色，且当前节点是左孩子
                    node.parent.color = "BLACK"
                    node.parent.parent.color = "RED"
                    self._right_rotate(node.parent.parent)
                    self.num_cases[3] += 1
            # 父节点是祖父节点的右孩子，与上面的情况完全相反
            else:
                uncle = node.parent.parent.left
                # 【情况4】叔节点是红色
                if uncle is not None and uncle.color == "RED":
                    # 父节点和叔节点涂黑，祖父节点涂红
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    node.parent.parent.color = "RED"
                    # 将祖父节点作为新的插入节点，继续进行修正
                    node = node.parent.parent
                    self.num_cases[4] += 1
                else:
                    # 【情况5】叔节点是黑色，且当前节点是左孩子
                    if node == node.parent.left:
                        # 将父节点作为新的插入节点，进行右旋
                        node = node.parent
                        self._right_rotate(node)
                        self.num_cases[5] += 1
                    # 【情况6】叔节点是黑色，且当前节点是右孩子
                    node.parent.color = "BLACK"
                    node.parent.parent.color = "RED"
                    self._left_rotate(node.parent.parent)
                    self.num_cases[6] += 1

        # 插入节点的父节点是黑色的，树仍然符合红黑树的性质，不需要做任何操作
        self.root.color = "BLACK"

    def _left_rotate(self, node):
        y = node.right
        # 将 y 的左孩子变为 node 的右孩子
        node.right = y.left
        # 如果 y 的左孩子非空，则将其父节点变为 node
        if y.left is not None:
            y.left.parent = node
        # 将 node 的父节点变为 y 的父节点
        y.parent = node.parent
        # 如果 node 是根节点，则将 y 也变为根节点
        if node.parent is None:
            self.root = y
        # 如果 node 是其父节点的左孩子，则将 y 也变为其父节点的左孩子
        elif node == node.parent.left:
            node.parent.left = y
        # 如果 node 是其父节点的右孩子，则将 y 也变为其父节点的右孩子
        else:
            node.parent.right = y
        # 将 node 变为 y 的左孩子
        y.left = node
        # 将 y 的父节点变为 node
        node.parent = y

    def _right_rotate(self, node):
        y = node.left
        # 将 y 的右孩子变为 node 的左孩子
        node.left = y.right
        if y.right is not None:
            y.right.parent = node
        # 将 node 的父节点变为 y 的父节点
        y.parent = node.parent
        if node.parent is None:
            self.root = y
        elif node == node.parent.right:
            node.parent.right = y
        else:
            node.parent.left = y
        # 将 node 变为 y 的右孩子
        y.right = node
        # 将 y 的父节点变为 node
        node.parent = y
    
    def count(self):
        print("RB_INSERT_FIXUP 算法历经的情况种类数：")
        for i in range(1, len(self.num_cases)):
            print(f"case {i}: {self.num_cases[i]}")

if __name__=='__main__':
    # 读取 insert.txt 文件中的数据
    with open("insert.txt", "r") as f:
        n = int(f.readline().strip())
        keys = list(map(int, f.readline().strip().split()))

    # 将数据插入红黑树
    rb_tree = RedBlackTree()
    for key in keys:
        rb_tree.insert(key)

    # 计算 RB_INSERT_FIXUP 算法历经的情况种类数
    rb_tree.count()

    # 输出遍历序列到文件
    def write_traversal_to_file(traversal, filename):
        with open(filename, "w") as f:
            for node in traversal:
                f.write(f"{node.key} {node.color}\n")

    # 中序遍历
    inorder_traversal = []
    def inorder(node):
        if node is not None:
            inorder(node.left)
            inorder_traversal.append(node)
            inorder(node.right)
    inorder(rb_tree.root)
    write_traversal_to_file(inorder_traversal, "LNR.txt")

    # 先序遍历
    preorder_traversal = []
    def preorder(node):
        if node is not None:
            preorder_traversal.append(node)
            preorder(node.left)
            preorder(node.right)
    preorder(rb_tree.root)
    write_traversal_to_file(preorder_traversal, "NLR.txt")

    # 层次遍历
    levelorder_traversal = []
    queue = [rb_tree.root]
    while len(queue) > 0:
        node = queue.pop(0)
        if node is not None:
            levelorder_traversal.append(node)
            queue.append(node.left)
            queue.append(node.right)
    write_traversal_to_file(levelorder_traversal, "LOT.txt")