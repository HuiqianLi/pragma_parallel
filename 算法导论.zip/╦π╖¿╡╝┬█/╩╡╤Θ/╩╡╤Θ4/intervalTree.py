class Interval:
    def __init__(self, low, high):
        self.low = low
        self.high = high

class Node:
    def __init__(self, interval):
        self.interval = interval
        self.color = 'RED'
        self.parent = None
        self.left = None
        self.right = None
        self.max = -float("inf")  # 将 T.NIL 的 max 值初始化为负无穷

class IntervalTree:
    def __init__(self):
        self.root = None
        self.num_cases = [0] * 7

    def insert(self, interval):
        node = Node(interval)
        self._insert_node(node)

    def _insert_node(self, node):
        # Binary Search Tree insert
        # 使用二叉搜索树的方式将节点插入到合适的位置
        parent = None
        curr = self.root
        while curr is not None:
            parent = curr
            curr = curr.left if node.interval.low < curr.interval.low else curr.right
        node.parent = parent
        if parent is None:
            self.root = node
        elif node.interval.low < parent.interval.low:
            parent.left = node
        else:
            parent.right = node

        # 'RED'-'BLACK' Tree fixup
        self._fixup(node)

        # Update max value of each node
        while node is not None:
            node.max = max(node.interval.high, node.left.max if node.left else -float("inf"), node.right.max if node.right else -float("inf"))
            node = node.parent

    def _fixup(self, node):
        while node.parent is not None and node.parent.color == 'RED':
            if node.parent == node.parent.parent.left:
                uncle = node.parent.parent.right
                # 【情况1】叔节点是红色
                if uncle is not None and uncle.color == 'RED':
                    # 父节点和叔节点涂黑，祖父节点涂红
                    node.parent.color = 'BLACK'
                    uncle.color = 'BLACK'
                    node.parent.parent.color = 'RED'
                    # 将祖父节点作为新的插入节点，继续进行修正
                    node = node.parent.parent
                    self.num_cases[1] += 1
                else:
                    # 【情况2】叔节点是黑色，且当前节点是右孩子
                    if node == node.parent.right:
                        # 将父节点作为新的插入节点，进行左旋
                        node = node.parent
                        self._left_rotate(node)
                        self.num_cases[2] += 1
                    # 【情况3】叔节点是黑色，且当前节点是左孩子
                    node.parent.color = 'BLACK'
                    node.parent.parent.color = 'RED'
                    self._right_rotate(node.parent.parent)
                    self.num_cases[3] += 1
            # 父节点是祖父节点的右孩子，与上面的情况完全相反
            else:
                uncle = node.parent.parent.left
                # 【情况4】叔节点是红色
                if uncle is not None and uncle.color == 'RED':
                    # 父节点和叔节点涂黑，祖父节点涂红
                    node.parent.color = 'BLACK'
                    uncle.color = 'BLACK'
                    node.parent.parent.color = 'RED'
                    # 将祖父节点作为新的插入节点，继续进行修正
                    node = node.parent.parent
                    self.num_cases[4] += 1
                else:
                    # 【情况5】叔节点是黑色，且当前节点是左孩子
                    if node == node.parent.left:
                        # 将父节点作为新的插入节点，进行右旋
                        node = node.parent
                        self._right_rotate(node)
                        self.num_cases[5] += 1
                    # 【情况6】叔节点是黑色，且当前节点是右孩子
                    node.parent.color = 'BLACK'
                    node.parent.parent.color = 'RED'
                    self._left_rotate(node.parent.parent)
                    self.num_cases[6] += 1
        # 插入节点的父节点是黑色的，树仍然符合红黑树的性质，不需要做任何操作
        self.root.color = 'BLACK'

    def _left_rotate(self, node):
        y = node.right

        # 将 y 的左孩子变为 node 的右孩子
        node.right = y.left
        if y.left is not None:
            y.left.parent = node

        # 将 node 的父节点变为 y 的父节点
        y.parent = node.parent
        if node.parent is None:
            self.root = y
        elif node == node.parent.left:
            node.parent.left = y
        else:
            node.parent.right = y

        # 将 node 变为 y 的左孩子
        y.left = node
        node.parent = y

        # 更新 node 和 y 的 max 值
        node.max = max(node.interval.high, node.left.max, node.right.max) if node.left is not None and node.right is not None else node.interval.high
        y.max = max(y.interval.high, y.left.max, y.right.max) if y.left is not None and y.right is not None else y.interval.high

    def _right_rotate(self, node):
        y = node.left

        # 将 y 的右孩子变为 node 的左孩子
        node.left = y.right
        if y.right is not None:
            y.right.parent = node

        # 将 node 的父节点变为 y 的父节点
        y.parent = node.parent
        if node.parent is None:
            self.root = y
        elif node == node.parent.right:
            node.parent.right = y
        else:
            node.parent.left = y

        # 将 node 变为 y 的右孩子
        y.right = node
        node.parent = y

        # 更新 node 和 y 的 max_val 值
        node.max = max(node.interval.high, node.left.max, node.right.max) if node.left is not None and node.right is not None else node.interval.high
        y.max_val = max(y.interval.high, y.left.max, y.right.max) if y.left is not None and y.right is not None else y.interval.high
    
    # 重叠区间
    def search_overlap(self, interval):
        overlaps = []
        curr = self.root # 从根节点开始遍历区间树
        while curr is not None:
            # 如果当前节点的区间与给定区间重叠，则将当前区间加入到 overlaps 列表中
            if curr.interval.high >= interval.low and curr.interval.low <= interval.high:
                overlaps.append([curr.interval.low, curr.interval.high])
                break
            # 如果当前节点的左子树的 max 值大于等于给定区间的左端点，
            # 则说明左子树中可能还有与给定区间重叠的区间，继续在左子树中搜索
            if curr.left is not None and curr.left.max >= interval.low:
                curr = curr.left
            # 否则，在右子树中搜索
            else:
                curr = curr.right
        return overlaps
    
    def count(self):
        print("RB_INSERT_FIXUP 算法历经的情况种类数：")
        for i in range(1, len(self.num_cases)):
            print(f"case {i}: {self.num_cases[i]}")

if __name__=='__main__':
    interval_tree = IntervalTree()
    # 从文件中读取待插入数据
    with open('insert.txt', 'r') as file:
        # 读取待插入数据的个数
        n = int(file.readline())

        # 依次插入每个区间
        for i in range(n):
            line = file.readline().strip().split()
            interval = Interval(int(line[0]), int(line[1]))
            interval_tree.insert(interval)

    # 计算 RB_INSERT_FIXUP 算法历经的情况种数
    interval_tree.count()

    # 输出遍历序列到文件
    def write_traversal_to_file(traversal, filename):
        with open(filename, "w") as f:
            for node in traversal:
                f.write(f"{node.interval.low, node.interval.high} {node.color}\n")

    # 中序遍历
    inorder_traversal = []
    def inorder(node):
        if node is not None:
            inorder(node.left)
            inorder_traversal.append(node)
            inorder(node.right)
    inorder(interval_tree.root)
    write_traversal_to_file(inorder_traversal, "LNR.txt")

    # 先序遍历
    preorder_traversal = []
    def preorder(node):
        if node is not None:
            preorder_traversal.append(node)
            preorder(node.left)
            preorder(node.right)
    preorder(interval_tree.root)
    write_traversal_to_file(preorder_traversal, "NLR.txt")

    # 层次遍历
    levelorder_traversal = []
    queue = [interval_tree.root]
    while len(queue) > 0:
        node = queue.pop(0)
        if node is not None:
            levelorder_traversal.append(node)
            queue.append(node.left)
            queue.append(node.right)
    write_traversal_to_file(levelorder_traversal, "LOT.txt")

    # 从控制台输入待查询数据
    while True:
        line = input("请输入待查询区间的左右端点（以空格分隔）：")
        line = line.strip().split()
        left, right = int(line[0]), int(line[1])
        if left > right:
            print("左端点必须小于等于右端点，请重新输入。")
            continue
        interval = Interval(int(line[0]), int(line[1]))
        print("重叠区间：", interval_tree.search_overlap(interval))