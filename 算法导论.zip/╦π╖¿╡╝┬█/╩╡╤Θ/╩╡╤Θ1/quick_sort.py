from typing import List
import time

# 固定基准
def partition(a: List[int], low: int, high: int) -> int:
    i = low - 1
    pivot = a[high]
    for j in range(low, high):
        if a[j] <= pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[high] = a[high], a[i + 1]
    return i + 1

def quick_sort(a: List[int], low: int, high: int) -> None:
    if low < high:
        pivot = partition(a, low, high)
        quick_sort(a, low, pivot - 1)
        quick_sort(a, pivot + 1, high)

# 随机基准
def randome_partition(a: List[int], low: int, high: int) -> int:
    import random
    i = random.randint(low, high)
    a[i], a[high] = a[high], a[i]
    return partition(a, low, high)

def randome_quick_sort(a: List[int], low: int, high: int) -> None:
    if low < high:
        pivot = randome_partition(a, low, high)
        randome_quick_sort(a, low, pivot - 1)
        randome_quick_sort(a, pivot + 1, high)

# 三数取中
def mid_partition(a: List[int], low: int, high: int) -> int:
    mid = (low + high) // 2
    if a[low] > a[mid]:
        a[low], a[mid] = a[mid], a[low]
    if a[low] > a[high]:
        a[low], a[high] = a[high], a[low]
    if a[mid] > a[high]:
        a[mid], a[high] = a[high], a[mid]
    a[mid], a[high] = a[high], a[mid]
    return partition(a, low, high)

def mid_quick_sort(a: List[int], low: int, high: int) -> None:
    if low < high:
        pivot = mid_partition(a, low, high)
        mid_quick_sort(a, low, pivot - 1)
        mid_quick_sort(a, pivot + 1, high)

# 插入排序
def insertion_sort(a: List[int]) -> None:
    n = len(a)
    for i in range(1, n):
        key = a[i]
        j = i - 1
        while j >= 0 and a[j] > key:
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = key

# 插入排序和快排结合，设置k值，数组长度小于k的部分使用插入排序，剩余快排
def new_quick_sort(a: List[int], low: int, high: int, k: int) -> None:
    if low < high and high - low + 1 > k:
        pivot = partition(a, low, high)
        new_quick_sort(a, low, pivot - 1, k)
        new_quick_sort(a, pivot + 1, high, k)

def hybrid_sort(a: List[int], k: int) -> None:
    new_quick_sort(a, 0, len(a) - 1, k)
    insertion_sort(a)

# 归并排序
def merge_sort(a: List[int], low: int, high: int) -> None:
    if low < high:
        mid = (low + high) // 2
        merge_sort(a, low, mid)
        merge_sort(a, mid + 1, high)
        merge(a, low, mid, high)

def merge(a: List[int], low: int, mid: int, high: int) -> None:
    n1 = mid - low + 1
    n2 = high - mid
    L = [0] * n1
    R = [0] * n2
    for i in range(n1):
        L[i] = a[low + i]
    for j in range(n2):
        R[j] = a[mid + 1 + j]
    i = j = 0
    k = low
    while i < n1 and j < n2:
        if L[i] <= R[j]:
            a[k] = L[i]
            i += 1
        else:
            a[k] = R[j]
            j += 1
        k += 1

# 堆排序
def heap_sort(a: List[int], low: int, high: int) -> None:
    n = len(a)
    for i in range(n // 2 - 1, -1, -1):
        heapify(a, n, i)
    for i in range(n - 1, 0, -1):
        a[i], a[0] = a[0], a[i]
        heapify(a, i, 0)

def heapify(a: List[int], n: int, i: int) -> None:
    largest = i
    l = 2 * i + 1
    r = 2 * i + 2
    if l < n and a[largest] < a[l]:
        largest = l
    if r < n and a[largest] < a[r]:
        largest = r
    if largest != i:
        a[i], a[largest] = a[largest], a[i]
        heapify(a, n, largest)
    
# 冒泡排序
def bubble_sort(a: List[int], low: int, high: int) -> None:
    n = len(a)
    for i in range(n):
        for j in range(n - i - 1):
            if a[j] > a[j + 1]:
                a[j + 1], a[j] = a[j], a[j + 1]

# 将sort函数作为参数传入，写一个main函数
def main(sort, func_name, exist_k=False, k=0):
    # start_time = time.time()

    with open('data.txt', 'r') as f:
        length = int(f.readline())
        # 读取非空行，使用 split() 方法分离每个整数字符串并转换为整数
        data = [int(x) for x in f.readline().strip().split() if x]

    start_time = time.time()
    
    # 调用快排
    if not exist_k:
        sort(data, 0, length-1)
    else:
        sort(data, k)

    end_time = time.time()

    with open('sorted.txt', 'w') as f:
        f.write(' '.join(map(str, data)))

    # end_time = time.time()
    print(f'{func_name} 运行时间为 {(end_time - start_time)*1000:.2f}毫秒')


if __name__=='__main__':
    main(quick_sort, func_name='quick_sort')
    main(randome_quick_sort, func_name='randome_quick_sort')
    main(mid_quick_sort, func_name='mid_quick_sort')

    main(merge_sort, func_name='merge_sort')
    main(heap_sort, func_name='heap_sort')
    # main(bubble_sort, func_name='bubble_sort')

    main(hybrid_sort,func_name='hybrid_sort_5', exist_k=True, k=5)
    main(hybrid_sort,func_name='hybrid_sort_10', exist_k=True, k=10)
    main(hybrid_sort,func_name='hybrid_sort_50', exist_k=True, k=50)