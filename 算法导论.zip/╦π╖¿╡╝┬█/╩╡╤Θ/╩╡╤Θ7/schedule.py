import sys
import time

n = 0                # 任务数
k = 0                # 机器数
t = []               # 完成任务 i 需要的时间 为t[i]
robot = []           # 第 i 个机器完成被分配的任务所花的时间
task_robot = []      # 任务与机器的映射
seq = []             # 最佳任务分配序列
best = sys.maxsize   # 最佳时间

def BestScheduling(i): # 搜索到树的第i层
    global best
    if best <= max(robot): # 剪枝
        return
    if i > n - 1:
        # 到达叶子结点，检查是否为更好的策略
        global seq
        seq = task_robot[:]  # 更新分配序列
        best = max(robot)
        return
    else:
        # 剪枝，将k个机器视为等价，若任务的时间（时间和）相等，则也可以把任务视为等价
        for j in range(k): # 展开每一个分支
            # 如果两个机器在分配一个任务后有相同的完成时间，由于上一个已经分配过，这个机器跳过
            flag = next((0 for m in range(j) if robot[j] == robot[m]), 1)
            if not flag:
                continue
            if robot[j] + t[i] < best: # 剪枝，best是最佳花费时间，如果比它还大没有必要计算了
                robot[j] += t[i]
                task_robot[i] = j
                BestScheduling(i + 1)
                robot[j] -= t[i] # 回溯
    return

def main(FileName):
    global n, k, t, task_robot, seq, robot, best
    begin = time.perf_counter()
    with open(FileName, 'r') as infile:
        n, k = map(int, infile.readline().split())
        t = list(map(int, infile.readline().split()))
    task_robot = [-1] * n
    seq = [-1] * n
    robot = [0] * k
    BestScheduling(0)
    print("最佳时间为：", best)
    print("最佳调度为：")
    for i in range(n):
        print(f"第{i + 1}个任务由第{seq[i] + 1}个机器完成")
    end = time.perf_counter()
    print("耗时 {:.4f}s".format(end - begin))
    t.clear()
    task_robot.clear()
    seq.clear()
    robot.clear()
    best = sys.maxsize

if __name__ == '__main__':
    print("test1:")
    main("test1.txt")    
    print("test2:")
    main("test2.txt")
    print("test3:")
    main("test3.txt")